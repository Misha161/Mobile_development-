from flask import Flask
from flask_restful import Api, Resource, reqparse
import sqlite3
import time

app = Flask(__name__)
api = Api(app)
connection = sqlite3.connect('db.sqlite3', check_same_thread=False)

class City_for_id (Resource):
    def get(self,id):
        with connection:
            cursor = connection.cursor()
            cursor.execute('SELECT * FROM sity WHERE id_city=?',(id,))
            result = cursor.fetchall()
            time.sleep(1)
            if len (result) > 0:
                return {"id_city":result[0][0],"title":result[0][1],"region":result[0][2]}
            return "error"
    def delete (self,id):
        with connection:
            cursor = connection.cursor()
            cursor.execute('Delete FROM sity WHERE id_city=?', (id,))
            connection.commit()
            return "ok"

    def put(self,id):
        with connection:
            cursor = connection.cursor()
            pars = reqparse.RequestParser()
            pars.add_argument("title", type=str, location="form")
            pars.add_argument("region", type=str, location="form")
            cursor.execute('Update sity set title =?, region =? where id_city =?',
                           (pars.parse_args()['title'], pars.parse_args()['region'],id))
            connection.commit()
            return "ok"

api.add_resource(City_for_id,'/city/<int:id>')

class City (Resource):
    def get(self):
        with connection:
            cursor = connection.cursor()
            cursor.execute('SELECT * FROM sity')
            result = cursor.fetchall()
            results = []
            for i in result:
                results.append({"id_city":i[0],"title":i[1],"region":i[2]})
            return {"results":results}
    def post(self):
        with connection:
            cursor = connection.cursor()
            pars = reqparse.RequestParser()
            pars.add_argument("title", type=str, location="form")
            pars.add_argument("region", type=str, location="form")
            cursor.execute('Insert into sity(title,region)values(?,?)',(pars.parse_args()['title'],pars.parse_args()['region']))
            connection.commit()
            return "ok"
api.add_resource(City,'/city')

class Type_for_id (Resource):
    def get(self, id):
        with connection:
            cursor = connection.cursor()
            cursor.execute('SELECT * FROM type_excursion WHERE id_type=?', (id,))
            result = cursor.fetchall()
            time.sleep(1)
            if len(result) > 0:
                return {"id_type": result[0][0], "title": result[0][1]}
            return "error"

    def delete(self, id):
        with connection:
            cursor = connection.cursor()
            cursor.execute('Delete FROM type_excursion WHERE id_type=?', (id,))
            connection.commit()
            return "ok"

    def put(self, id):
        with connection:
            cursor = connection.cursor()
            pars = reqparse.RequestParser()
            pars.add_argument("title", type=str, location="form")
            cursor.execute('Update type_excursion set title =? where id_type =?',
                           (pars.parse_args()['title'], id))
            connection.commit()
            return "ok"
api.add_resource(Type_for_id,'/type_excursion/<int:id>')

class Type (Resource):
    def get(self):
        with connection:
            cursor = connection.cursor()
            cursor.execute('SELECT * FROM type_excursion')
            result = cursor.fetchall()
            results = []
            for i in result:
                results.append({"id_type": i[0], "title": i[1]})
            return {"results": results}

    def post(self):
        with connection:
            cursor = connection.cursor()
            pars = reqparse.RequestParser()
            pars.add_argument("title", type=str, location="form")
            cursor.execute('Insert into type_excursion(title)values(?)',
                           (pars.parse_args()['title'],))
            connection.commit()
            return "ok"

api.add_resource(Type, '/type_excursion')

class Client (Resource):
    def get(self):
        with connection:
            cursor = connection.cursor()
            cursor.execute('SELECT * FROM clients_user')
            result = cursor.fetchall()
            results = []
            for i in result:
                results.append({"name": i[0], "password": i[1]})
            return {"results": results}

    def post(self):
        with connection:
            cursor = connection.cursor()
            pars = reqparse.RequestParser()
            pars.add_argument("name", type=str, location="form")
            pars.add_argument("password", type=str, location="form")
            cursor.execute('Insert into clients_user(name,password)values(?,?)',
                           (pars.parse_args()['name'],pars.parse_args()['password'],))
            connection.commit()
            return "ok"

api.add_resource(Client, '/clients_user')

class Excursion_for_id (Resource):
    def get(self, id):
        with connection:
            cursor = connection.cursor()
            cursor.execute('SELECT excersion.id_excursion,'
                           ' excersion.title,excersion.price,excersion.seasonal_holiday,'
                           'excersion.id_type,excersion.id_city, type_excursion.title,'
                           'sity.title FROM excersion, type_excursion,sity WHERE excersion.id_excursion=?'
                           ' and excersion.id_city = sity.id_city and excersion.id_type = type_excursion.id_type', (id,))
            result = cursor.fetchall()
            if len(result) > 0:
                return {"id_excursion": result[0][0], "title": result[0][1], "price": result[0][2],
                        "seasonal_holiday": result[0][3], "id_type": result[0][4], "id_city": result[0][5],"type_excursion": result[0][6],"sity":result[0][7]}
            return "error"

    def delete(self, id):
        with connection:
            cursor = connection.cursor()
            cursor.execute('Delete FROM excersion WHERE id_excursion=?', (id,))
            connection.commit()
            return "ok"

    def put(self, id):
        with connection:
            cursor = connection.cursor()
            pars = reqparse.RequestParser()
            pars.add_argument("id_type", type=int, location="form")
            pars.add_argument("title", type=str, location="form")
            pars.add_argument("price", type=int, location="form")
            pars.add_argument("seasonal_holiday", type=str, location="form")
            pars.add_argument("id_city", type=int, location="form")

            cursor.execute('Update excersion set id_type =?,id_city =?,title =?,price = ?, '
                           'seasonal_holiday =? where id_excursion =?',
                           (pars.parse_args()['id_type'], pars.parse_args()['id_city'], pars.parse_args()['title'],
                            pars.parse_args()['price'], pars.parse_args()['seasonal_holiday'], id))
            connection.commit()
            return "ok"


api.add_resource(Excursion_for_id, '/excersion/<int:id>')

class Excursion (Resource):
    def get(self):
        with connection:
            cursor = connection.cursor()
            cursor.execute('SELECT excersion.id_excursion,excersion.title,excersion.price,excersion.seasonal_holiday,excersion.id_type,excersion.id_city, type_excursion.title,sity.title FROM excersion, type_excursion,sity WHERE excersion.id_city = sity.id_city and excersion.id_type = type_excursion.id_type')
            result = cursor.fetchall()
            results = []
            for i in result:
                results.append({"id_excursion": i[0], "title": i[1], "price": i[2],
                        "seasonal_holiday": i[3], "id_type": i[4], "id_city": i[5],
                         "type_excursion": i[6], "sity":i[7]})
            return {"results": results}

    def post(self):
        with connection:
            cursor = connection.cursor()
            pars = reqparse.RequestParser()
            pars.add_argument("id_type", type=int, location="form")
            pars.add_argument("title", type=str, location="form")
            pars.add_argument("price", type=int, location="form")
            pars.add_argument("seasonal_holiday", type=str, location="form")
            pars.add_argument("id_city", type=int, location="form")

            cursor.execute('Insert into excersion(id_type, id_city, title, price,'
                           'seasonal_holiday)values (?,?,?,?,?)',
                           (pars.parse_args()['id_type'], pars.parse_args()['id_city'],
                            pars.parse_args()['title'],pars.parse_args()['price'],pars.parse_args()['seasonal_holiday'],))
            connection.commit()
            return "ok"


api.add_resource(Excursion, '/excersion')


api.init_app(app)
if __name__ == "__main__":
    app.run(host="192.168.1.25", port=5000, debug=True)